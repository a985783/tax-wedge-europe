Dear Editor,

I am pleased to submit our manuscript titled "**The Tax Wedge: High-Frequency Identification of Indirect Tax Shocks and Price Rigidity in Europe**" for consideration of publication in [Journal Name].

Understanding the transmission of indirect taxes is central to fiscal policy design and inflation dynamics. However, the literature has been constrained by the difficulty of identifying tax shocks at a frequency high enough to capture price adjustments. This paper overcomes this challenge by constructing a novel "Tax Wedge" indicator—exploiting the mechanical difference between the HICP and HICP at Constant Tax Rates—to automate the detection of over 20,000 tax shocks across 30 European countries from 1996 to 2024.

Our analysis yields a striking result that challenges the prevailing "rockets and feathers" consensus: we find **symmetric pass-through**. In our broad, pan-European sample, prices respond to tax cuts just as rapidly and fully as they do to tax hikes. This suggests that the European Single Market’s competitive pressures may be more effective at disciplining margins than previously thought.

We further document significant heterogeneity: pass-through is nearly complete for non-durable goods in core economies but significantly muted in peripheral economies and for durable goods. These findings provide a nuanced, large-scale empirical baseline for nominal rigidity models and offer immediate policy implications for the use of VAT cuts as stimulus.

This paper is not under consideration elsewhere. We confirm that we have no conflicts of interest to disclose.

Thank you for your consideration.

Sincerely,

[Your Name/Author Team]
[Affiliation]

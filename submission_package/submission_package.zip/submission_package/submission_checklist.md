# Submission Checklist

## General Requirements
- [ ] **PDF Length**: ~30-40 pages (including References & Figures).
- [ ] **Formatting**: Double-spaced or 1.5 spaced, 12pt font, 1-inch margins.
- [ ] **Anonymity**: Ensure `paper.pdf` is fully anonymized (no author names).
- [ ] **Title Page**: Separate file with Author Names, Affiliations, Contact Info, Acknowledgments.

## Specific Material
- [x] **Abstract**: < 150 words (Currently ~140 words).
- [x] **JEL Codes**: H22 (Incidence), E31 (Price Level), E62 (Fiscal Policy).
- [x] **Keywords**: VAT, Tax Incidence, Pass-through, High-Frequency Identification, Price Rigidity.
- [x] **Cover Letter**: Tailored to Editor, highlighting the "Symmetry" contribution.

## Data & Replication
- [ ] **Data Availability Statement**: "The data underlying this article are available from Eurostat (publicly accessible). Code for replication is provided in the supplementary material."
- [ ] **Replication Package**:
    - `data/raw/`: Instructions on how to download from Eurostat.
    - `src/`: Cleaned Python scripts (`clean.py`, `models.py`).
    - `README.md`: Step-by-step replication guide.

## Figures & Tables
- [x] **Figures**: High resolution (300 DPI+). Ensure axis labels are readable.
- [x] **Tables**: Self-contained notes. Significance stars explained.

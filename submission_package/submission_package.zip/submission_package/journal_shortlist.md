# Journal Shortlist & Submission Strategy

## Tier A: The "Moonshot" (Aim High)
### **American Economic Journal: Economic Policy (AEJ: Policy)**
*   **Rationale**: The paper uses a clean identification strategy (quasi-experimental) to answer a major policy question (tax incidence). AEJ: Policy values credible identification and clear policy relevance. The "Symmetric Pass-through" finding challenges standard narratives, which is attractive for general interest.
*   **Fit**: High. Your "Tax Wedge" instrument is a methodological contribution they will appreciate.
*   **Risk**: They might demand even more structural modeling to explain *why* symmetry holds (mechanisms).

### **Journal of Public Economics (JPubE)**
*   **Rationale**: The top field journal for public finance. This is the natural home for a high-quality tax incidence paper.
*   **Fit**: Perfect. The audience cares deeply about VAT pass-through, and the pan-European scope is a major plus compared to single-country studies.
*   **Risk**: High bar for novelty. You must emphasize how this differs from Benzarti et al. (2020) – your "Symmetry" result is the key differentiator.

## Tier B: The "Sweet Spot" (High Probability)
### **European Economic Review (EER)**
*   **Rationale**: Top European general interest journal.
*   **Fit**: Excellent. The data is European, the policy context is EU-wide. They will value the cross-country heterogeneity analysis (Core vs. Periphery).
*   **Preference**: Loves large-scale empirical work with European data.

### **International Tax and Public Finance (ITAX)**
*   **Rationale**: Solid field journal.
*   **Fit**: Very high. If JPubE rejects, this is the immediate next step. They published Benedek et al. (2020), so they are part of this conversation.

## Tier C: The "Safety Net"
### **Journal of Macroeconomics**
*   **Rationale**: Good outlet if the contribution is seen as more empirical/measurement-focused than theoretical.
*   **Fit**: Good. The high-frequency identification angle appeals to macro audiences.

---

## Submission Strategy
1.  **Start with AEJ: Policy**. The "Symmetric" finding is a strong enough hook.
2.  **If Desk Rejected**, go to **JPubE**.
3.  **If Rejected after Review**, incorporate comments and target **EER**.

# Reviewer Attack List & Defense Strategy

## Attack 1: "The Identification is Mechanical / Circular"
**Critique**: "You are just subtracting two Eurostat series. How do we know this reflects *actual* legislative changes and not just measurement error or re-weighting artifacts?"
**Defense**:
*   **Validation**: Point to Section 3.2. We manually audited 500 events and found <2% false positives.
*   **Flags**: We cross-checked with Eurostat's own 't' (tax change) flags.
*   **Threshold**: The 1% threshold is conservative, filtering out small noise.
*   **Pre-trends**: The flat pre-trends in the event study prove that the identified shocks are not endogenous to prior price movements.

## Attack 2: "Symmetry contradicts Benzarti et al. (2020)"
**Critique**: "Benzarti et al. (AER 2020) found strong asymmetry (rockets and feathers). Why is your result different? Is your data wrong?"
**Defense**:
*   **Scope**: Benzarti et al. focus heavily on specific sectors (e.g., hairdressers, restaurants) in specific countries (Finland, France). We cover the *entire* consumption basket across 30 countries.
*   **Competition**: Our sample is dominated by tradable goods (food, electronics) where competition is fierce, forcing symmetry. Theirs is service-heavy.
*   **Sample Period**: We include the post-2020 high-inflation period and recent years, where pricing dynamics might differ.
*   **We embrace the difference**: We don't say they are wrong; we say the *aggregate* reality is symmetric, even if specific protected sectors are not.

## Attack 3: "Anticipation Effects"
**Critique**: "VAT changes are announced months in advance. Firms raise prices *before* the hike. Your t=0 is too late."
**Defense**:
*   **Visual Evidence**: Look at Figure 1. There is no significant movement at t=-1 or t=-2.
*   **Frequency**: Monthly data is high-frequency enough to capture the implementation month. Even if announced, sticky prices often mean the actual tag change happens on the effective date.

## Attack 4: "External Validity / Heterogeneity"
**Critique**: "You pool Bulgaria with Germany. These markets are totally different."
**Defense**:
*   **Heterogeneity Section**: We explicitly model this in Section 5.2. We *show* that Core != Periphery. We don't claim a "one size fits all" parameter, but the *methodology* is valid everywhere.
*   **Fixed Effects**: Our stacked design includes Country-Sector fixed effects, so we are comparing within-unit changes.

## Attack 5: "Is it just Energy?"
**Critique**: "Your results are driven by volatile energy taxes."
**Defense**:
*   **Robustness**: We can run the model excluding Energy. (Ensure you have this or can argue it based on the Durable/Non-durable split where Non-durable includes Food too).
*   **Sector Split**: We show results for Non-durables (Food+Energy) and Durables separately. Both show distinct patterns, so it's not *just* energy noise.
